"""ORBITCARE 5X FastAPI application entry point (M0 scaffold).

Serves the JSON API under /api and the static frontend at / when the
frontend/ directory exists.
"""
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

APP_VERSION = "0.1.0"

app = FastAPI(title="ORBITCARE 5X", version=APP_VERSION)


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "version": APP_VERSION}


# parents[0]=app, parents[1]=backend, parents[2]=project root
FRONTEND_DIR = Path(__file__).resolve().parents[2] / "frontend"
if FRONTEND_DIR.is_dir():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")

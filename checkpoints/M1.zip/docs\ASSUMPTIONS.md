# ORBITCARE 5X — Assumptions

- The PLAN was supplied as `PLAN.md.docx` and extracted to `PLAN.md` (text).
- Division status: GREEN >= 75; YELLOW 35 to 74.9; RED < 35.
- Letter grade: A+ >= 95; A 90 to 94.9; (further bands per CONTRACT §3).
- Bottleneck cap: if any division score < 35, the total is capped at 54.9 (Grade D maximum).
- Compounding penalty (-10) is applied before the bottleneck cap.
- All deduction coefficients are illustrative defaults (CONTRACT §3), not validated science.
- 31 scenarios = every non-empty subset of the 5 hazards (bitmask 1..31), plus scenario 0 = Day-1 nominal.
- NO_DATA divisions (all required inputs null) are excluded from the total, and the remaining weights are renormalised.
- Hazard interaction flags are hypotheses drawn from HRP hazard descriptions, not validated coefficients.
- Crew, vitals and cabin telemetry are fictional and SIMULATED.
- Local Python on this machine is 3.10.11; the Dockerfile uses Python 3.11.
- Git is not installed on this machine; milestones are checkpointed as zip snapshots in `checkpoints/` until git is available.
- earth_distance "other division flagged" means YELLOW or RED; NO_DATA does not count.
- NO_DATA divisions are excluded from the weighted total, the penalty count and the bottleneck check.
- A single null input skips that factor only; the division is still scored from its other inputs.
- The weighted total is rounded to 1 dp before the penalty and the cap are applied.
- The sample generator uses seed 42 and is fully SIMULATED.

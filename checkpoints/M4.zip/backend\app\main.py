﻿"""ORBITCARE 5X FastAPI application entry point.

Serves the JSON API under /api and the static frontend at / when the
frontend/ directory exists.
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from . import db
from .api import assessments, spaceweather, telemetry

APP_VERSION = "0.1.0"


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="ORBITCARE 5X", version=APP_VERSION, lifespan=lifespan)
app.include_router(telemetry.router)
app.include_router(assessments.router)
app.include_router(spaceweather.router)


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "version": APP_VERSION}


# parents[0]=app, parents[1]=backend, parents[2]=project root
FRONTEND_DIR = Path(__file__).resolve().parents[2] / "frontend"
if FRONTEND_DIR.is_dir():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")



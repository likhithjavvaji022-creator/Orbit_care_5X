# ORBITCARE 5X — Progress

## Done
- M0 scaffold: requirements.txt, .env.example, .gitignore, Dockerfile, backend package skeleton, `GET /api/health`, conditional static mount of frontend/, frontend/index.html placeholder with disclaimer footer.
- CONTRACT: docs/CONTRACT.md (interface contract, source of truth).
- M1 grading engine: backend/app/engine/config.py and grading.py (CONTRACT §3), 14 golden tests passing.
- Simulated 31-scenario sample data (seed 42, fully SIMULATED).

## In progress
- M2 backend pipeline and API (CONTRACT §1 data models and db.py, 7-stage pipeline, telemetry/assessment API per CONTRACT §4).
- M3 frontend sections per CONTRACT §1 and PLAN §5.

## Decisions
- Frontend mount is conditional on frontend/ existing, so the API runs before the UI exists.
- Dockerfile uses python:3.11-slim (PLAN §4 requires Python 3.11+); local dev Python on this machine is 3.10.11.
- .gitignore does not ignore dist/ (single-file build output must be committed).
- Zip checkpoints instead of git commits: git is not installed, so milestones are snapshotted as zip files in checkpoints/ until git is available.

## Status (2026-11-14)

**Done**
- M2: pipeline, SQLite, upload and ingest (tests passing).
- M3: shell and Mission Control.
- M4: HUD and Crew Health (browser-verified).
- M6: NOAA backend (live real call verified).

**In progress**
- M5: Guard tabs.
- M6: frontend pages.

**Next**
- M7: Simulator, NASA Research, Reports, Settings, single-file build, Playwright, Docker, demo script, README.

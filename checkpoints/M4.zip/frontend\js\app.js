﻿import { notConnected, esc } from './ui.js';
import * as mission from './pages/mission-control.js';
import * as hud from './pages/hud.js';

const SECTIONS = [
  { id: 'mission-control', title: 'Mission Control', page: mission },
  { id: 'space-weather', title: 'Space Weather' },
  { id: 'radiation-guard', title: 'Radiation Guard' },
  { id: 'crew-health', title: 'Crew Health', page: hud, opts: { mode: 'crew' } },
  { id: 'guards', title: '5X Guards', sub: 'Gravity / Life Support / Earth Distance' },
  { id: 'ai-risk', title: 'AI Risk Analysis' },
  { id: 'flight-surgeon-hud', title: 'Flight Surgeon HUD', page: hud, opts: { mode: 'hud' } },
  { id: 'mission-simulator', title: 'Mission Simulator' },
  { id: 'nasa-research', title: 'NASA Research' },
  { id: 'alerts', title: 'Alerts Centre' },
  { id: 'reports', title: 'Reports & Analytics' },
  { id: 'settings', title: 'Settings' },
];

const view = document.getElementById('view');
const nav = document.getElementById('nav');
const sidebar = document.getElementById('sidebar');
const drawerBtn = document.getElementById('drawerBtn');
let cleanup = null;

nav.innerHTML = SECTIONS.map((s, i) => `<a href="#/${s.id}" data-id="${s.id}">${i + 1}. ${esc(s.title)}${s.sub ? `<small>${esc(s.sub)}</small>` : ''}</a>`).join('');
drawerBtn.onclick = () => { const o = sidebar.classList.toggle('open'); drawerBtn.setAttribute('aria-expanded', o); };

function route() {
  const id = (location.hash.replace(/^#\/?/, '') || SECTIONS[0].id);
  const sec = SECTIONS.find((s) => s.id === id) || SECTIONS[0];
  if (typeof cleanup === 'function') { try { cleanup(); } catch (_) { /* ignore */ } }
  cleanup = null;
  sidebar.classList.remove('open'); drawerBtn.setAttribute('aria-expanded', 'false');
  nav.querySelectorAll('a').forEach((a) => (a.dataset.id === sec.id ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
  document.title = sec.title + ' - ORBITCARE 5X';
  if (sec.page) {
    cleanup = sec.page.render(view, sec.opts || {}) || null;
  } else {
    view.innerHTML = notConnected(sec.title, sec.sub || '');
  }
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', route);
route();

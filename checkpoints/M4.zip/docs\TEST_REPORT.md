# ORBITCARE 5X — Test Report

## M1 grading engine (date 2026-11-14)

Command:

```
python -m pytest backend/tests/test_grading.py -q
```

Output:

```
..............                                                           [100%]
14 passed in 0.04s
```

Exit code: 0. Result: 14 passed, 0 failed.

## M2+M6 backend (2026-11-14)

Command: `python -m pytest backend/tests -q`

```
..........................                                               [100%]
============================== warnings summary ===============================
..\..\AppData\Local\Programs\Python\Python310\lib\site-packages\fastapi\testclient.py:1
  C:\Users\srila\AppData\Local\Programs\Python\Python310\lib\site-packages\fastapi\testclient.py:1: StarletteDeprecationWarning: Using `httpx` with `starlette.testclient` is deprecated; install `httpx2` instead.
    from starlette.testclient import TestClient as TestClient  # noqa

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
26 passed, 1 warning in 3.00s
```

## M3/M4 browser E2E (manual, built-in browser pane)

- Upload of 32-row sample: received 32, accepted 32, rejected 0, suspect 53, 7 stages shown.
- 5 tiles. Total 39.6 D YELLOW, delta -58.9, with -10 penalty and bottleneck cap badges.
- 3 interaction flags.
- Trajectory: 32 points.
- Live stream added days 33-35, then stopped.
- HUD and Crew Health rendered.
- No console errors.
- 375px: no horizontal overflow.
- Note: node is absent, so node:test was not run.
